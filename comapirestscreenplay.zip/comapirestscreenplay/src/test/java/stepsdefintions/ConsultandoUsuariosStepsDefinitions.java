package stepsdefintions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;

import java.util.List;

import static net.bddtrader.portfolios.TradeType.Buy;
import static net.bddtrader.portfolios.TradeType.Sell;
import static org.assertj.core.api.Assertions.assertThat;


public class ConsultandoUsuariosStepsDefinitions {
    @Given("^Soy un usuario autorizado$")
    public void soyUnUsuarioAutorizado() {
    }

    @When("^solicito información de los usuarios de la URI <uri>$")
    public void solicitoInformaciónDeLosUsuariosDeLaURIUri(String urix|) {
    }

    @Then("^debería obtener información de forma satisfactoria$")
    public void deberíaObtenerInformaciónDeFormaSatisfactoria() {
    }
}
